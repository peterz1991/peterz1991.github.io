%=================
% Caution: Line 82 to 85 are buggy, need to be fixed
%=================
clear all
rng(888)          % re-producible research
X = phantom(256); % Perfect Image

%=============================== 
% Part I: Creating experimental data: 
%           Partial Fourier data with Guassian noise
%===============================

%--------------------Making Fan type Mask in Fourier Domain----------------
n = size(X,1);          % X is a square matrix with dimension n x n.
angles = 100;            % fan-beam mask with 50 angles.
sigma = 0.05;           % noise level

Fan_Mask= fftshift(MRImask(n,angles));
idx = find(Fan_Mask~=0);
len = nnz(Fan_Mask);    % number of nonzeros in Mask;
K = fft2(X).*Fan_Mask;  % simulate partial Fourier data K
K(idx) = K(idx)+sigma*(randn(len,1)+1i*randn(len,1));% add complex noise

x1 = ifft2(K);          % Original (masked) Image

%-----------------------------Visualization--------------------------------
imagesc(X);colormap(gray);title('X');figure(); 
imagesc(Fan_Mask);colormap(gray);title('Fan type Mask unshifted');figure()
imagesc(log(abs((fftshift(K)))));colormap(gray);title('Fan type Mask');figure();
imshow(fft2(x1));colormap(gray);title('Original Image')


%% 
%===============================
% Part II: Implementing Bregman Splitting/ADMM Algorithm
%===============================

%----------------------------------------------
% Undersampled Fourier data is fk
% Mask is M, reconstruct object is x (in time domain)
% So original we have M*F*f = fk.
% Here we consider the case m = 2, ([1 -2 1])
%----------------------------------------------

fk = K; f0 = fk; f = ifft2(fk);
M = double(Fan_Mask); 

myshrink = @(y,alpha) sign(y).*max(abs(y)-alpha,0);
Bx = @(f) padarray(f,[0 1],'replicate');
Lx = @(f)  diff(Bx(f),2,2);
By = @(f) padarray(f,[1 0],'replicate');
Ly = @(f) diff(By(f),2,1);

Lxm2 = abs(psf2otf([1 -2 1],[n,n])).^2;
Lym2 = abs(psf2otf([1; -2; 1],[n,n])).^2;

%--------Intialize relative error----------
%--We will use this as stopping criteria---
rela.beta = 100; 
rela.z1 = 100; 
rela.z2 = 100;
maxiter = 20;

%------Tuning variables to do denoising----
mu = .1; 
lambda = .15;


k = 0; 
z1 = zeros(n,n);
z2 = zeros(n,n);
b1 = zeros(n,n);
b2 = zeros(n,n);

while k<maxiter && rela.beta(end)>0.001
%     
    % storage the former step
    beta0 = f;
    z10 = z1;
    z20 = z2;
    
    % Main algorithm // Attention! The following is buggy!
    rhs = mu/lambda*M.*fk+fft2(Lx((z1-b1)))+fft2(Ly((z2-b2)));
    denom = mu/lambda*M+Lxm2+Lym2;
    f =  ifft2(rhs./denom) ;

    %---------- z-sub problem------------
    z1 = myshrink(Lx(f)+b1,1/lambda);
    z2 = myshrink(Ly(f)+b2,1/lambda);
    
    %---------- b-sub problem------------
    b1 = b1 +(Lx(f)-z1);
    b2 = b2 +(Ly(f)-z2);
    
    fk = fk + f0 - M.*fft2(f);
    k = k+1;
    
    rela.beta = [rela.beta norm(f-beta0,'fro')/norm(beta0,'fro')];
    rela.z1 = norm(z10-z1,'fro')/norm(z10,'fro');
    rela.z2 = norm(z20-z2,'fro')/norm(z20,'fro');
    figure(1)
    imshow(f);colormap(gray)
    drawnow
end


% figure()
% imagesc(real(ifft2(y)));colormap(gray)
% rela_x(ii,jj) = norm(beta-X,'fro')/norm(X,'fro');
[mse,peaksnr,rela_err] = Err_analysis(X,f);
rela_y = norm(ifft2(fk)-X,'fro')/norm(X,'fro');
figure()
imagesc(abs(f));colormap(gray)
title(['TV with error ',num2str(rela_err)],'FontSize',20)