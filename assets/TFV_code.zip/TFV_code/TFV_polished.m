%% Preprocessing Image
clear all
X = double(imread('Lena512.png'));
[m,n] = size(X); % X is a square matrix with dimension nxn.
sigma = 0.05;
z = X(:) + sigma*randn(m*n,1)*max(X(:));
z = reshape(z,m,n);
show(z)
%% Split Bregman
% Model: min 1/2||u-z||_2^2 + mu*(||B1*u||_1+||B2*u||_1) 
% => 1/2||u-z||_2^2 + mu*(||d1||_1+||d2||_1) + lambda/2*||B1*u-d1+P1||_2^2
%                                            + lambda/2*||B2*u-d2+P2||_2^2

close all

alpha = 1.8;

% Generate B-matrix
BN = generate_B(n,alpha);
BM = generate_B(m,alpha);
BN = sptoeplitz(BN(1,:));
BM = sptoeplitz(BM(1,:));
BigBN = kron(speye(m),BN);
BigBM = kron(BM,speye(n));

Uk = z;
show(Uk)

P1 = zeros(m,n);
P2 = zeros(m,n);
D1 = P1;
D2 = P2;

rela_err = 1;
gamma = 1;
lambda = 1;
mu = 20;
k = 1; 
myshrink = @(y,alpha) sign(y).*max(abs(y)-alpha,0);
while k<40 && rela_err > 1e-3
    U = Uk;
    % solve subproblem u by conjugate gradient
    rhs = z - lambda*(BN*(P1-D1)+(P2-D2)*BM);   
    vec_U = pcg(BigBN'*BigBN+BigBM'*BigBM+speye(m*n),rhs(:));
    Uk = reshape(vec_U,m,n);
    
    % solve subproblem d
    D1 = myshrink(BN*Uk+P1,mu/lambda);
    D2 = myshrink(BigBM*Uk(:)+P2(:),mu/lambda);
    D2 = reshape(D2,m,n);
    
    % update P matrices
    P1 = P1 + gamma*(BN*Uk-D1);
    P2 = P2(:) + gamma*(BigBM*Uk(:)-D2(:));
    P2 = reshape(P2,m,n);
    
    rela_err = norm(Uk-U,'fro')/(norm(Uk,'fro')+eps);
    k = k+1; 
    
    figure(1)
    show(Uk)
    title(['relative err = ',num2str(rela_err)])
    drawnow
end

figure();
subplot(131);show(X);title('Original');axis image;
subplot(132);show(z);title([num2str(sigma),' noise']);axis image;
subplot(133);show(Uk);title(['\alpha = ', num2str(alpha),' Recon']);axis image; 