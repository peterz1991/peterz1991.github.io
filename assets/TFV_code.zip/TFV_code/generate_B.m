function BN = generate_B(N,alpha)
% N = 10;
% alpha = 1.2;
    w = [1];
    for j = 1:N
        t = w(end)*(1-(1+alpha)/j);
        w = [w t];
    end
    w = w(2:end);
    w(1) = 2*w(1);
    w(2) = 1+w(2);
    W = toeplitz(w);
    BN = W/2;
    BN = BN.*(abs(BN)>1e-3);
end