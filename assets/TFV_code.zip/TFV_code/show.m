function show(X)
imagesc(X);
colormap(gray)
